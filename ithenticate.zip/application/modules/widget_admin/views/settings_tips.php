<div class="side_container tips">
	<?= heading("About Settings",2); ?>
	<p>
		You can change settings anytime you want. Settings allow you to customize your preferences for documents and reports.
	</p>
</div>
<div class="clear"></div>