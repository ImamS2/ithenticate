<div class="side_container confirm_tip">
	<?= heading("Acceptable Formats",2); ?>
	<ul>
		<li>MS Excel 2007 (.xlsx)</li>
	</ul>
	<b>
		<?= anchor(base_url("assets/uploads/sampleformat.xlsx"),"View examples"); ?>
	</b>
</div>
<div class="clear"></div>