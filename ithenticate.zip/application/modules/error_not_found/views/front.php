		<div class="row">
			<div class="span12">
				<h2>Page not found</h2>
			</div>
		</div>
	</div>
</section>
<section class="top">
	<div class="container">
		<div class="row">
			<span id="hs_cos_wrapper_main_copy" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text">
				<h2>Error 404</h2>
				<p>Sorry, the page you were looking for at this URL was not found.</p>
			</span>
		</div>
	</div>
</section>
<style>
	@media (max-width: 768px) {
		.offset3 {
			float: left;
            text-align: center;
        }

        .span3 {
        	width: 140px;
            margin: 1em;
        }
    }
}
</style>