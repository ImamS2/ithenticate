Array
(
    [params] => Array
        (
            [param] => Array
                (
                    [value] => Array
                        (
                            [struct] => Array
                                (
                                    [member] => Array
                                        (
                                            [0] => Array
                                                (
                                                    [name] => api_status
                                                    [value] => Array
                                                        (
                                                            [int] => 401
                                                        )

                                                )

                                            [1] => Array
                                                (
                                                    [name] => status
                                                    [value] => Array
                                                        (
                                                            [int] => 401
                                                        )

                                                )

                                            [2] => Array
                                                (
                                                    [name] => response_timestamp
                                                    [value] => Array
                                                        (
                                                            [dateTime.iso8601] => 2019-07-23T19:42:02Z
                                                        )

                                                )

                                            [3] => Array
                                                (
                                                    [name] => messages
                                                    [value] => Array
                                                        (
                                                            [array] => Array
                                                                (
                                                                    [data] => Array
                                                                        (
                                                                            [value] => Array
                                                                                (
                                                                                    [string] => Failed to provide authenticated sid
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                        )

                                )

                        )

                )

        )

)