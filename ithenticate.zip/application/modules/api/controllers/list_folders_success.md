Array
(
    [params] => Array
        (
            [param] => Array
                (
                    [value] => Array
                        (
                            [struct] => Array
                                (
                                    [member] => Array
                                        (
                                            [0] => Array
                                                (
                                                    [name] => folders
                                                    [value] => Array
                                                        (
                                                            [array] => Array
                                                                (
                                                                    [data] => Array
                                                                        (
                                                                            [value] => Array
                                                                                (
                                                                                    [struct] => Array
                                                                                        (
                                                                                            [member] => Array
                                                                                                (
                                                                                                    [0] => Array
                                                                                                        (
                                                                                                            [name] => name
                                                                                                            [value] => Array
                                                                                                                (
                                                                                                                    [string] => My Documents
                                                                                                                )

                                                                                                        )

                                                                                                    [1] => Array
                                                                                                        (
                                                                                                            [name] => id
                                                                                                            [value] => Array
                                                                                                                (
                                                                                                                    [int] => 1588047
                                                                                                                )

                                                                                                        )

                                                                                                    [2] => Array
                                                                                                        (
                                                                                                            [name] => group
                                                                                                            [value] => Array
                                                                                                                (
                                                                                                                    [struct] => Array
                                                                                                                        (
                                                                                                                            [member] => Array
                                                                                                                                (
                                                                                                                                    [0] => Array
                                                                                                                                        (
                                                                                                                                            [name] => name
                                                                                                                                            [value] => Array
                                                                                                                                                (
                                                                                                                                                    [string] => My Folders
                                                                                                                                                )

                                                                                                                                        )

                                                                                                                                    [1] => Array
                                                                                                                                        (
                                                                                                                                            [name] => id
                                                                                                                                            [value] => Array
                                                                                                                                                (
                                                                                                                                                    [int] => 1264712
                                                                                                                                                )

                                                                                                                                        )

                                                                                                                                )

                                                                                                                        )

                                                                                                                )

                                                                                                        )

                                                                                                )

                                                                                        )

                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [1] => Array
                                                (
                                                    [name] => response_timestamp
                                                    [value] => Array
                                                        (
                                                            [dateTime.iso8601] => 2019-07-23T19:39:10Z
                                                        )

                                                )

                                            [2] => Array
                                                (
                                                    [name] => api_status
                                                    [value] => Array
                                                        (
                                                            [int] => 200
                                                        )

                                                )

                                            [3] => Array
                                                (
                                                    [name] => sid
                                                    [value] => Array
                                                        (
                                                            [string] => 43f89a4e7e1f08565bc16aa5f4d96b72350346ed
                                                        )

                                                )

                                            [4] => Array
                                                (
                                                    [name] => status
                                                    [value] => Array
                                                        (
                                                            [int] => 200
                                                        )

                                                )

                                        )

                                )

                        )

                )

        )

)